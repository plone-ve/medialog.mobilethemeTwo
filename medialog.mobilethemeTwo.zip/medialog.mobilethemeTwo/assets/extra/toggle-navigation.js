$(document).ready(function() {
   $('#toggle-navigaton').click(function() {
            $('.navbar-fixed-top').toggle();
    });

}(jQuery));
